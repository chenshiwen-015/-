const assert=require('node:assert/strict');const M=require('../dist/template-model.js');
const base={layout:'collage',brand:'品牌A',product:'商品A',year:'2026',collectionTitle:'Everyday Collection',collectionSubtitle:'2026 Edit',headline:'原始主标题',caption1:'图注',fontSize:47,bg:'#eee6da',backgroundPreset:'solid',backgroundWash:0};
assert.deepEqual(M.spec('paper').keys,['collectionTitle','collectionSubtitle','tagLeft','tagRight','paperTape','product']);
assert(!M.spec('paper').keys.includes('caption1'));assert(M.spec('street').keys.includes('product4Caption'));assert(!M.spec('street').keys.includes('year'));assert(M.spec('lookbook').keys.includes('lookbookFooter'));assert(!M.spec('lookbook').keys.includes('paperTape'));
let state={...base},sources={background:''},bank=M.createBank(base,state,sources);for(const d of Object.values(bank))assert.equal(d.background.preset,'solid');
function choose(target){const result=M.prepareSwitch(state,sources,bank,target,base);bank=result.bank;state={...state,...result.patch};sources.background=result.source;}
choose('paper');state.collectionTitle='纸感自定义';state.bg='#abc123';state.backgroundPreset='custom';sources.background='data:image/png;base64,aGVsbG8=';
choose('lookbook');assert.equal(state.collectionTitle,'Everyday Collection');assert.equal(state.backgroundPreset,'solid');assert.equal(sources.background,'');assert.equal(state.brand,'品牌A');state.collectionTitle='Lookbook 自定义';
choose('paper');assert.equal(state.collectionTitle,'纸感自定义');assert.equal(state.bg,'#abc123');assert.equal(state.backgroundPreset,'custom');assert(sources.background.startsWith('data:'));
choose('lookbook');assert.equal(state.collectionTitle,'Lookbook 自定义');
const restored=M.createBank(base,state,sources,JSON.parse(JSON.stringify(bank)));assert.equal(restored.paper.values.collectionTitle,'纸感自定义');
assert.equal(M.sanitize('paper',{background:{preset:'custom',source:'https://untrusted.invalid/x.png',color:'invalid'}},base).background.preset,'solid');
assert.deepEqual(M.activeAssets('lookbook',base),['model','look2','reference']);
console.log('PASS: template-specific fields/assets, independent text drafts, default solid backgrounds, intentional uploaded-background restore, safe project round-trip');
