const assert=require('node:assert/strict');
const {removeConnectedBackground}=require('../dist/image-tools.js');
const w=9,h=9,a=new Uint8ClampedArray(w*h*4);
for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;const object=x>=2&&x<=6&&y>=2&&y<=6;a.set(object?[30,60,100,255]:[244,241,235,255],i)}
// White enclosed detail stays opaque: the flood only removes the edge-connected background.
a.set([244,241,235,255],(4*w+4)*4);
const snapshot=new Uint8ClampedArray(a),out=removeConnectedBackground(a,w,h,20);
assert.equal(out.removed,56);assert.equal(out.data[3],0);assert.equal(out.data[(4*w+4)*4+3],255);assert.deepEqual(a,snapshot);
const b=new Uint8ClampedArray(a);for(let i=0;i<b.length;i+=4)if(b[i]===244)b.set([20,20,20,255],i);
const dark=removeConnectedBackground(b,w,h,20);assert.equal(dark.data[3],0);assert.equal(dark.data[(3*w+3)*4+3],255);
const {normalize}=require('../dist/image-transform.js');assert.equal(normalize().opacity,1);assert.equal(normalize({opacity:0}).opacity,0);assert.equal(normalize({opacity:.37}).opacity,.37);assert.equal(normalize({opacity:5}).opacity,1);
console.log('PASS: light/dark background matting, preserved interior detail, unchanged originals, opacity zero/default/clamp');
const {cleanAlpha}=require('../dist/image-tools.js');
const noisy=new Uint8ClampedArray(30*30*4);for(let y=5;y<25;y++)for(let x=10;x<20;x++)noisy.set([120,80,50,255],(y*30+x)*4);noisy.set([250,250,250,255],(2*30+2)*4);
const clean=cleanAlpha(noisy,30,30);assert.equal(clean[(2*30+2)*4+3],0);assert.equal(clean[(12*30+15)*4+3],255);assert.equal(noisy[(2*30+2)*4+3],255);
console.log('PASS: AI mask speckles cleaned without altering the subject or original pixels');
