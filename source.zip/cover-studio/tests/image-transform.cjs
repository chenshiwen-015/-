const assert = require('node:assert/strict');
const {normalize, rectangle} = require('../dist/image-transform.js');
// Regression: square images at 100% used to have no horizontal OR vertical movement.
for (const contain of [true, false]) {
  const base = rectangle(800,800,220,220,{},contain);
  const moved = rectangle(800,800,220,220,{offsetX:25,offsetY:-20},contain);
  assert.equal(moved.x-base.x,55); assert.equal(moved.y-base.y,-44);
}
// Position remains usable on the fitted axis for portrait / landscape images too.
for (const [iw,ih] of [[800,1200],[1600,800]]) {
  const base=rectangle(iw,ih,200,300,{},true), moved=rectangle(iw,ih,200,300,{offsetX:20,offsetY:20},true);
  assert.equal(moved.x-base.x,40); assert.equal(moved.y-base.y,60);
}
const small=rectangle(800,800,220,220,{zoom:.5},true);
assert.ok(Math.abs(small.width-110)<1e-8); assert.ok(Math.abs(small.x-55)<1e-8);
// The old crop appearance is preserved until a user moves it with the new controls.
assert.deepEqual(rectangle(800,800,200,100,{zoom:2,x:20,y:40}), {x:-40,y:-120,width:400,height:400});
// Stored values are validated and independent records never share a mutable object.
const a=normalize(), b=normalize(); a.offsetX=60; a.zoom=.4;
assert.equal(b.offsetX,0); assert.equal(b.zoom,1);
assert.equal(normalize({zoom:NaN,offsetY:999}).offsetY,100);
console.log('PASS: exact-fit movement on both axes, shrink, old project positions, independent records');
