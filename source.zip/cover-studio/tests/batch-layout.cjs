const assert=require('node:assert/strict'),B=require('../dist/batch-layout.js');
const item=(id,role)=>({id,role,src:'data:image/png;base64,eA=='});
assert.equal(B.suggest('商品主图.jpg'),'product');assert.equal(B.suggest('商品面料细节.png'),'detail');assert.equal(B.suggest('上身2.jpg'),'model');assert.equal(B.suggest('IMG_0001.jpg'),'auto');
const assets=[item('m1','model'),item('m2','model'),item('p1','product'),item('d1','detail')];
for(const layout of ['paper','lookbook','street','collage','editorial','split','full']){const p=B.plan(layout,assets);assert.equal(p.slots.product,'p1');assert.equal(p.hero,'model');assert(Object.values(p.slots).every(id=>assets.some(a=>a.id===id)));assert(p.used.length+p.remaining===assets.length);}
const p=B.plan('collage',assets);assert.equal(p.slots.polaroid1,'m2');assert.equal(p.slots.detail1,'d1');assert.equal(p.slots.detail2,'d1');assert(!p.slots.product2);
const a=B.plan('lookbook',[item('a','auto'),item('b','auto')]);assert.equal(a.slots.model,'a');assert.equal(a.slots.look2,'b');
const single=B.plan('paper',[item('p','product')]);assert.equal(single.hero,'product');assert.equal(single.slots.product,'p');assert.equal(single.remaining,0);
const text=B.copy('collage','亚麻长裤','','品牌','2026');assert.equal(text.headline,'亚麻长裤');assert.equal(text.features,'');assert(!JSON.stringify(text).includes('莫代尔'));assert.equal(text.swatches,'');
const provided=B.copy('collage','衬衫','100%棉\n宽松版型','品牌','2026');assert.equal(provided.features,'100%棉\n宽松版型');
assert.equal(B.copy('paper','衬衫','','','2026').collectionTitle,'衬衫');assert.equal(B.copy('lookbook','衬衫','','','2026').collectionSubtitle,'衬衫');
console.log('PASS: role suggestions, seven template plans, uploaded-source-only fallbacks, extra-image retention, and no invented product facts');
